package com.meals.bruce.meal_test01;

import org.junit.Test;

/**
 * Created by Bruce on 2018-01-16.
 */
public class tab1Test {
    @Test
    public void onCreateView() throws Exception {
    }

}
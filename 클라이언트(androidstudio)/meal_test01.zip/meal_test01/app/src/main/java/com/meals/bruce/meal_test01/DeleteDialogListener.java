package com.meals.bruce.meal_test01;

/**
 * Created by Bruce on 2018-01-24.
 */

public interface DeleteDialogListener {
    public void onPositiveClicked(String pass);
    public void onNegativeClicked();
}

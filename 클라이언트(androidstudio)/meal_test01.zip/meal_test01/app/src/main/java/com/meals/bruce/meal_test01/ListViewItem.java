package com.meals.bruce.meal_test01;

import android.graphics.drawable.Drawable;

public class ListViewItem {
    private Drawable icon1;
    private Drawable icon2;
    private String appr;

    public Drawable getIcon1() {
        return icon1;
    }

    public void setIcon1(Drawable icon1) {
        this.icon1 = icon1;
    }

    public Drawable getIcon2() {
        return icon2;
    }

    public void setIcon2(Drawable icon2) {
        this.icon2 = icon2;
    }

    public String getAppr() {
        return appr;
    }

    public void setAppr(String appr) {
        this.appr = appr;
    }



}